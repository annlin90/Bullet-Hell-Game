﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;

namespace CptS_487_game.Menus
{
    class Menu
    {
        private SpriteFont font;

        public enum GameState { menu,game, replay, player, music, opts };
        public GameState menuState = GameState.menu;
        
        private Color[] fontColors = new Color[7];
        private Rectangle[] menuOpts = new Rectangle[7];
        string[] menuItems = { "Game Start", "Extra Start", "Replay", "Player", "Music", "Options", "Quit" };
        public void Initialize(SpriteFont sf)
        {
            
            font = sf;
            for (int i = 0; i < 7; i++)
            {
                menuOpts[i] = new Rectangle(100, 100 + 50 * i, 200, 35);
                //each rectangle represents a menu item, as coded in Draw()
                fontColors[i] = Color.Black;
            }
        }

        public int Update(GameTime gt)
        {
            var mouseState = Mouse.GetState();
            var mousePoint = new Point(mouseState.X, mouseState.Y);
            //check if any menu options have been clicked on via mouse
            //menu items change color when hovered
            for (int i = 0; i < menuOpts.Length; i++)
            {
                // playArea = new Rectangle(100, 100 + 50 * i, 200, 35);
                if (menuOpts[i].Contains(mousePoint))
                {
                    fontColors[i] = Color.White;
                    
                }
                else
                { fontColors[i] = Color.Black; }
            }

            if(  mouseState.RightButton == ButtonState.Pressed)
              {
                if (menuOpts[0].Contains(mousePoint))
                {
                    return 1;
                    menuState = GameState.game;
                }//play game
                if (menuOpts[5].Contains(mousePoint))
                { menuState = GameState.opts; }//go to options
                if (menuOpts[6].Contains(mousePoint))
                { return 2; }//exit game
            }
            return 0;
        }

        public void Draw(SpriteBatch sb)
        {
            if(menuState == GameState.menu)
            {
                sb.DrawString(font, "Mountain of Faith", new Vector2(200, 50), Color.Black);
                for(int i = 0; i <menuItems.Length; i ++ )
                {
                    sb.DrawString(font, menuItems[i], new Vector2(100, 100 + 50 * i), fontColors[i]);
                }
            }
            else if (menuState == GameState.game)
            {
                sb.DrawString(font, "Menu", new Vector2(450, 450), Color.Black);
            }
            else if(menuState == GameState.opts)
            {
                sb.DrawString(font, "Options", new Vector2(200, 50), Color.Black);
            }
            
        }
    }
}
