﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CptS_487_game.Interfaces;
using CptS_487_game.Interfaces.Shooting;
using CptS_487_game.MovementFactory;
using CptS_487_game.Objects;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;

namespace CptS_487_game.EntityDecorator
{
    class DecoratorShooterDownWave : DecoratorShooter
    {
        //IShooter _shooter;
        //ShooterFactory shooterFactory;
        TimeSpan decoratedRateOfBullets;
        public DecoratorShooterDownWave(Entity entity) : base(entity)
        {
            //shooterFactory = new ShooterFactory();
            //_shooter = shooterFactory.CreateProduct("Enemy");
            decoratedRateOfBullets = TimeSpan.FromSeconds(0.05);
        }

        public override List<Entity> Shoot(GameTime gt, KeyboardState cks)
        {
            //Entity bullet = null;
            //IEntityBuilder entityBuilder = _shooter.Shoot(gt, cks, _entity.RateOfBullets);
            //if (entityBuilder != null) {
            //    _entity.EntityDirector.Construct(entityBuilder, _entity.Position);
            //    bullet = entityBuilder.GetResult();
            //}
            List<Entity> decoratedBullets = new List<Entity>();
            //Entity bullet = null;
            //IEntityBuilder entityBuilder = _shooter.Shoot(gt, cks, _entity.RateOfBullets);
            //if (entityBuilder != null) {
            //    _entity.EntityDirector.Construct(entityBuilder, _entity.Position);
            //    bullet = entityBuilder.GetResult();
            //}
            List<Entity> basic = _entity.Shoot(gt, cks);

            if (basic != null)
            {
                foreach (Entity e in basic)
                {
                    decoratedBullets.Add(new DecoratorMovementDownWave(e));
                }
                return decoratedBullets;
            }
            return basic;

        }
    }
}
