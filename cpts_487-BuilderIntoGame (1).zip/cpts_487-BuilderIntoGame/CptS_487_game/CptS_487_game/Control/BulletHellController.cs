﻿using CptS_487_game.Builder;
using CptS_487_game.EntityDecorator;
using CptS_487_game.EntityFactorys;
using CptS_487_game.Interfaces;
using CptS_487_game.MovementFactory.Movements;
using CptS_487_game.Objects;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CptS_487_game.Control;

namespace CptS_487_game.Control
{
    class BulletHellController
    {
        Game _game;
        SpriteBatch _sb;
        SpawningController spawnController;
        Entity Player;
        List<Entity> PlayerBullets;
        List<Entity> Enemies;
        EntityDirector Director;
        Random random;
        float enemySpawnTimer1;
        float enemySpawnTimer2;
        float midBossSpawnTimer;
        float finalBossSpawnTimer;

        EntityFactory entityFactory;

        //Integrate multiple controllers
        MovementController mc;

        public BulletHellController(Game game)
        {
            //Testing spawning controller json parsing
            var level = "TestLevel.json";
            spawnController = new SpawningController(game);
            spawnController.LevelParser(level);

            //

            Player = new ConcreteEntity();
            PlayerBullets = new List<Entity>();
            Enemies = new List<Entity>();
            Director = new EntityDirector(game);
            entityFactory = new EntityFactory(game);
            _game = game;

            // Enemy spawn helpers
            random = new Random();
            // Controllers
            mc = new MovementController(game);
        }

        public void Initialize(SpriteBatch sb)
        {
            _sb = sb;
        }

        public void Update(GameTime gameTime)
        {
            spawnController.SpawnEntities(gameTime, ref Player,ref Enemies);
            spawnController.DespawnEntities(gameTime, ref Enemies);
            mc.MoveAll(Player, PlayerBullets, Enemies); ///TODO: Doesn't work off timers
            ShootAll(gameTime);
            //MoveAll(); ///TODO: Doesn't work off timers
            
            CheckCollisions();
        }

        public void CheckCollisions()
        {
            //my stuff collision code stuff
            Rectangle rectangle1;
            Rectangle rectangle2;
            Rectangle rectangle3;
            Rectangle rectangle4;

            Rectangle rectangle5;
            Rectangle rectangle6;




            rectangle1 = new Rectangle((int)Player.Position.X, (int)Player.Position.Y, Player.Width, Player.Height);


            // Kill the player when colliding with DemonEnemy
            for (int i = 0; i < Enemies.Count; i++)
            {
                rectangle2 = new Rectangle((int)Enemies[i].Position.X, (int)Enemies[i].Position.Y, (int)Enemies[i].Width, (int)Enemies[i].Height);
                if (rectangle1.Intersects(rectangle2))
                {






                    Player = Enemies[i].ApplyEffect(Player);







                    Enemies[i].Active = false;
                    Enemies.RemoveAt(i);
                    i--;

                }
            }

            // Check if fireball intersects with demon enemy
            for (int i = 0; i < PlayerBullets.Count; i++)
            {
                for (int x = 0; x < Enemies.Count; x++)
                {
                    rectangle4 = new Rectangle((int)PlayerBullets[i].Position.X, (int)PlayerBullets[i].Position.Y,
                     (int)PlayerBullets[i].Width, (int)PlayerBullets[i].Height);

                    rectangle3 = new Rectangle((int)Enemies[x].Position.Y, (int)Enemies[x].Position.Y, (int)Enemies[x].Width, (int)Enemies[x].Height);

                    if (rectangle4.Intersects(rectangle3))
                    {
                        Enemies[x] = PlayerBullets[i].ApplyEffect(Enemies[x]);
                        // Subtract demon health when fireball hits
                        Enemies[i].Active = false;
                        Enemies.RemoveAt(i);
                        x--;
                        // Remove fireball from list
                        PlayerBullets.RemoveAt(i);
                        i--;
                        break;


                    }
                }
            }

        }
 
        public void ShootAll(GameTime gameTime)
        {
            GetBullet(Player, PlayerBullets, gameTime);

            for (var i = Enemies.Count - 1; i >= 0; --i) // So we can add to Enemies during loop
                GetBullet(Enemies[i], Enemies, gameTime);
        }

        private void GetBullet(Entity entity, List<Entity> bulletList, GameTime gameTime)
        {
            List<Entity> bullet = entity.Shoot(gameTime, Keyboard.GetState());

            if (bullet != null)
            {
                bulletList.AddRange(bullet);
            }
        }

        public void Draw(GameTime gameTime)
        {
            _sb.Begin();

            Player.Draw(_sb);

            foreach (var e in PlayerBullets)
                e.Draw(_sb);

            foreach (var e in Enemies)
                e.Draw(_sb);

            _sb.End();
        }
    }
}
