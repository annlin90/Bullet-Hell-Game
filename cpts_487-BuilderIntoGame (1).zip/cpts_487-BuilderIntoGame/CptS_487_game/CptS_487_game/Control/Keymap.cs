﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework.Input;


namespace CptS_487_game.Control
{
    public class Keymap
    {
        private static readonly Keymap instance = new Keymap();
        public Keys Up
        {
            get; set;
        }
        public Keys Down
        {
            get; set;
        }
        public Keys Left
        {
            get; set;
        }
        public Keys Right
        {
            get; set;
        }
        public Keys Shoot
        {
            get; set;
        }
        public Keys Slowdown
        {
            get; set;
        }
        private Keymap()
        {
            Up = Keys.Up;
            Down = Keys.Down;
            Left = Keys.Left;
            Right = Keys.Right;
            Shoot = Keys.Z;
            Slowdown = Keys.LeftShift;
        }
        
        public static Keymap GetInstance()
        { 
            return instance;
        }
    }
}
