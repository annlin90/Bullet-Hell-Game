Bullet Hell Game
