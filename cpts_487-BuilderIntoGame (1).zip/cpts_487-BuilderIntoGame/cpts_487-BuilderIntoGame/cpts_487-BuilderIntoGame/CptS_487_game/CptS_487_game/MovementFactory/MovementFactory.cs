﻿using CptS_487_game.Interfaces.Movement;
using CptS_487_game.MovementFactory.Movements;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CptS_487_game.MovementFactory
{
    class MovementCreator
    {
        public IMovable CreateProduct(string movement)
        {
            movement = movement.ToLower();

            switch (movement)
            {
                case ("player"):
                    return new PlayerMovement();
                case ("enemywave"):
                    return new EnemyMovementWave();
                case ("enemystraight"):
                    return new EnemyMovementStraight();
                case ("playerbullet"):
                    return new PlayerBulletMovement();
                case ("enemybullet"):
                    return new EnemyBulletMovement();
                case ("enemybulletwave"):
                    return new EnemyBulletMovementWave();
                default:
                    return null;
            }
        }
    }
}
