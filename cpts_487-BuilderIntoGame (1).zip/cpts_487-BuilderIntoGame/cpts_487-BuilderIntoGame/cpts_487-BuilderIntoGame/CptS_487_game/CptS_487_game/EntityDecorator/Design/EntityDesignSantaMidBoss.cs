﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CptS_487_game.Objects;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace CptS_487_game.EntityDecorator
{
    class EntityDesignSantaMidBoss : EntityDesignDecorator
    {
        Texture2D _decoratedTexture;

        public EntityDesignSantaMidBoss(Entity entity) : base(entity)
        {
            //This is where the decoration happens
            //we change the texture to a different texture but keep everything else about the entity the same
            _decoratedTexture = entity.Game.Content.Load<Texture2D>("santa_chara");
        }

        public override void Draw(SpriteBatch sb)
        {
            Texture2D SantaTxt = _decoratedTexture;
            Rectangle newBounds = SantaTxt.Bounds;
            const int resizeBy = 0;
            //newBounds.X += resizeBy;
            //newBounds.Y += resizeBy;
            newBounds.Width -= resizeBy * 5;
            newBounds.Height -= resizeBy * 7;

            //cropping texture
            Color[] data = new Color[newBounds.Width * newBounds.Height];
            SantaTxt.GetData(0, newBounds, data, 0, newBounds.Width * newBounds.Height);

            sb.Draw(SantaTxt, _entity.Position, newBounds, Color.White, 1f, Vector2.Zero, 0f,
                SpriteEffects.None, 0f);

            //sb.Draw(_texture, _position, newBounds, Color.White, 0f, Vector2.Zero, 1f, SpriteEffects.None, 0f);

            //sb.Draw(_decoratedTexture, _entity.Position, null, Color.White, 0f, Vector2.Zero, 1f, SpriteEffects.None, 0f);
        }
    }
}
