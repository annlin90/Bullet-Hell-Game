﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CptS_487_game.Interfaces;
using CptS_487_game.Interfaces.Shooting;
using CptS_487_game.MovementFactory;
using CptS_487_game.Objects;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;

namespace CptS_487_game.EntityDecorator.Powerup
{
    class EnemyPowerupWave : EntityPowerupDecorator
    {
        IShooter _shooter;
        ShooterFactory shooterFactory;

        public EnemyPowerupWave(Entity entity) : base(entity)
        {
            shooterFactory = new ShooterFactory();
            _shooter = shooterFactory.CreateProduct("Enemy");
        }

        public override Entity Shoot(GameTime gt, KeyboardState cks)
        {
            Entity bullet = null;
            IEntityBuilder entityBuilder = _shooter.Shoot(gt, cks, _entity.RateOfBullets);
            if (entityBuilder != null) {
                _entity.EntityDirector.Construct(entityBuilder, _entity.Position);
                bullet = entityBuilder.GetResult();
            }
            return bullet;
        }
    }
}
