﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CptS_487_game.Interfaces;
using CptS_487_game.Objects;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;

namespace CptS_487_game.EntityDecorator.Powerup
{
    class EntityPowerupDouble : EntityPowerupDecorator
    {
        public EntityPowerupDouble(Entity entity) : base(entity)
        {
        }

        public override Entity Shoot(GameTime gt, KeyboardState cks)
        {
            throw new NotImplementedException();
        }
    }
}
