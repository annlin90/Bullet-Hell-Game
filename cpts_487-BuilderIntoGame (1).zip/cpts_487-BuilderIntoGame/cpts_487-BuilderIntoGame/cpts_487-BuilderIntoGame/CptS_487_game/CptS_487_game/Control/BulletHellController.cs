﻿using CptS_487_game.Builder;
using CptS_487_game.EntityDecorator;
using CptS_487_game.EntityDecorator.Powerup;
using CptS_487_game.Interfaces;
using CptS_487_game.Objects;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CptS_487_game.Control
{
    class BulletHellController
    {
        Game _game;
        SpriteBatch _sb;
        
       public Entity Player;
        List<Entity> PlayerBullets;
        List<Entity> Enemies;
        EntityDirector Director;
        Random random;
        int enemiesSpawned;
        float enemySpawnTimer1;
        float enemySpawnTimer2;
        float midBossSpawnTimer;
        float finalBossSpawnTimer;
        bool midBossSpawned;
        bool finalBossSpawned;

        public BulletHellController(Game game)
        {
            Player = new ConcreteEntity();
            PlayerBullets = new List<Entity>();
            Enemies = new List<Entity>();
            Director = new EntityDirector(game);
            _game = game;

            // Enemy spawn helpers
            random = new Random();
            enemiesSpawned = 0;
            enemySpawnTimer1 = 0;
            enemySpawnTimer2 = 0;
            midBossSpawnTimer = 0;
            finalBossSpawnTimer = 0;
            midBossSpawned = false;
            finalBossSpawned = false;
        }

        public void Initialize(SpriteBatch sb)
        {
            PlayerBuilder playerBuilder = new PlayerBuilder();
            Director.Construct(playerBuilder, new Vector2(_game.GraphicsDevice.Viewport.TitleSafeArea.X + _game.GraphicsDevice.Viewport.TitleSafeArea.Width / 2,
                _game.GraphicsDevice.Viewport.TitleSafeArea.Y + 3 * _game.GraphicsDevice.Viewport.TitleSafeArea.Height / 2));
            Player = playerBuilder.GetResult();
            
            // Use this to draw textures
            _sb = sb;
        }

        public void Update(GameTime gameTime)
        {
            enemySpawnTimer1 += (float)gameTime.ElapsedGameTime.TotalSeconds;
            enemySpawnTimer2 += (float)gameTime.ElapsedGameTime.TotalSeconds;
            midBossSpawnTimer += (float)gameTime.ElapsedGameTime.TotalSeconds;
            finalBossSpawnTimer += (float)gameTime.ElapsedGameTime.TotalSeconds;
            PurgeAll(); // Removes all enemies unconditionally
            LoadEnemies(); // Works off spawn timers
            MoveAll(); ///TODO: Doesn't work off timers
            ShootAll(gameTime);
            CheckCollisions();
        }

        public void CheckCollisions()
        {
            //my stuff collision code stuff
            Rectangle rectangle1;
            Rectangle rectangle2;
            Rectangle rectangle3;
            Rectangle rectangle4;

            Rectangle rectangle5;
            Rectangle rectangle6;




            rectangle1 = new Rectangle((int)Player.Position.X, (int)Player.Position.Y, Player.Width, Player.Height);
            int hit = 0;

            // Kill the player when colliding with DemonEnemy
            for (int i = 0; i < Enemies.Count; i++)
            {
                rectangle2 = new Rectangle((int)Enemies[i].Position.X, (int)Enemies[i].Position.Y, (int)Enemies[i].Width, (int)Enemies[i].Height);
                if (rectangle1.Intersects(rectangle2))
                {
                    hit += 1;
                    if (hit == 3)
                    //respawn at original location
                    {
                        Player.Position = new Vector2(_game.GraphicsDevice.Viewport.TitleSafeArea.X + _game.GraphicsDevice.Viewport.TitleSafeArea.Width / 2,
                      _game.GraphicsDevice.Viewport.TitleSafeArea.Y + 3 * _game.GraphicsDevice.Viewport.TitleSafeArea.Height / 2);
                        //lose a life
                        Player.Health -= 1; // removes all stars.. why?
                        hit = 0;
                    }
                    //stop bullets for a couple seconds
                    //if(Player.Health == 0)
                    //{
                    //    //end game curState = gameOver
                    //}

                    Enemies[i].Active = false;
                    Enemies.RemoveAt(i);
                    i--;
                    
                }
            }

            

            // Check if fireball intersects with demon enemy
            for (int i = 0; i < PlayerBullets.Count; i++)
            {
                for (int x = 0; x < Enemies.Count; x++)
                {
                    rectangle4 = new Rectangle((int)PlayerBullets[i].Position.X, (int)PlayerBullets[i].Position.Y,
                     (int)PlayerBullets[i].Width, (int)PlayerBullets[i].Height);

                    rectangle3 = new Rectangle((int)Enemies[i].Position.Y, (int)Enemies[i].Position.Y, (int)Enemies[i].Width, (int)Enemies[i].Height);

                    if (rectangle4.Intersects(rectangle3))
                    {
                        // Subtract demon health when fireball hits
                        Enemies[i].Active = false;
                        Enemies.RemoveAt(i);
                        x--;
                        // Remove fireball from list
                        PlayerBullets.RemoveAt(i);
                        i--;
                        break;


                    }
                }
            }

        }

        public void PurgeAll()
        {
            PurgeEnemies();
            PurgePlayerBullets();       
        }

        public void PurgeEnemies()
        {
            //For all enemies remove if not active
            var removeThese = new List<Entity>();
            foreach (var e in Enemies)
                if (!e.Active)
                    removeThese.Add(e);
            foreach (Entity e in removeThese)
                Enemies.Remove(e);
        }

        public void PurgePlayerBullets()
        {
            //For all player bullets remove if not active
            var removeThese = new List<Entity>();
            foreach (var e in PlayerBullets)
                if (!e.Active)
                    removeThese.Add(e);
            foreach (Entity e in removeThese)
                PlayerBullets.Remove(e);
        }
 
        public void MoveAll()
        {
            Player.Move();
            MovePlayerBullets();
            MoveEnemies();
            
        }

        public void MovePlayerBullets()
        {
            foreach (var e in PlayerBullets)
            {
                e.Move();
                if (e.Position.Y < 0)
                    e.Active = false;
            }
        }

        public void MoveEnemies()
        {
            foreach (var e in Enemies)
            {
                e.Move();
                if (e.Position.Y > _game.GraphicsDevice.Viewport.Height)
                    e.Active = false;
            }
        }

        public void ShootAll(GameTime gameTime)
        {
            GetBullet(Player, PlayerBullets, gameTime);

            for (var i = Enemies.Count - 1; i >= 0; --i) // So we can add to Enemies during loop
                GetBullet(Enemies[i], Enemies, gameTime);
        }

        private void GetBullet(Entity entity, List<Entity> bulletList, GameTime gameTime)
        {
            Entity bullet = entity.Shoot(gameTime, Keyboard.GetState());

            if (bullet != null)
            {
                bulletList.Add(bullet);
            }
        }

        public void LoadEnemies()
        {
            if (enemySpawnTimer1 >= 1 && !midBossSpawned)
            {
                enemySpawnTimer1 = 0;

                if (enemiesSpawned < 4)
                {
                    int randX = random.Next(0, 120);
                    var enemyBuilder = new EnemyBuilder();
                    Director.Construct(enemyBuilder, new Vector2(randX, 0));
                    Enemies.Add(enemyBuilder.GetResult());
                    enemiesSpawned++;
                }
            }

            if (enemySpawnTimer2 >= 1.8 && !midBossSpawned)
            {
                enemySpawnTimer2 = 0;

                if (enemiesSpawned < 5)
                {
                    int randX = random.Next(120, 240 - 32);
                    var enemyBuilder = new EnemyBuilder();
                    Director.Construct(enemyBuilder, new Vector2(randX,0));
                    Enemies.Add(new EnemyPowerupWave(new EntityDesignRedPlane(enemyBuilder.GetResult())));
                    //Enemies.Add(enemyBuilder.GetResult());
                    enemiesSpawned++;
                }
            }

            //Spawning bosses as a regular enemy, in the future impliment decorator to change the texture.
            if (midBossSpawnTimer >= 5 && !midBossSpawned)
            {
                var enemyBuilder = new EnemyBuilder();
                Director.Construct(enemyBuilder, new Vector2(5, -25));
                Enemies.Add(new EntityDesignSantaMidBoss(enemyBuilder.GetResult()));
                midBossSpawned = true;
            }

            if (finalBossSpawnTimer >= 10 && !finalBossSpawned)
            {
                var enemyBuilder = new EnemyBuilder();
                Director.Construct(enemyBuilder, new Vector2(45, 25));
                Enemies.Add(enemyBuilder.GetResult());
                finalBossSpawned = true;
            }
        }

        public void Draw(GameTime gameTime)
        {
            _sb.Begin();

            Player.Draw(_sb);
            Player.DrawLives(_sb);
            
            foreach (var e in PlayerBullets)
                e.Draw(_sb);

            foreach (var e in Enemies)
                e.Draw(_sb);

            _sb.End();
        }
    }
}
