﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace CptS_487_game
{
    class DiagonalBullet : Bullet
    {
        int _slope = 4;
        bool _goingUp;


        public override void Initialize(string texture, Vector2 position, float speed, int damage)
        {
            _bulletTexture = Game1._content.Load<Texture2D>(texture);
            BulletMoveSpeed = speed;
            Position = position;
            Damage = damage;
            Active = true;
            _goingUp = true;
        }

        public override void Move()
        {
            //Just move straight
            Position.X += BulletMoveSpeed;
            if (_goingUp) Position.Y += _slope; 
        }
    }
}
