﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;

namespace CptS_487_game
{
    abstract class Entity
    {
        protected Texture2D _texture;
        protected Texture2D _bulletTexture;
        protected Vector2 _position;
        protected bool _active;
        protected bool _firstShot;
        protected int _health; //Not yet implemented
        protected int _viewPortWidth;
        protected int _viewPortHeight;

        protected TimeSpan _rateOfBullets;
        protected TimeSpan _previousBulletSpawnTime;

        public  List<Bullet> _bullets; //Not sure yet

        //Getters/setters
        public int Width
        {
            get { return _texture.Width; }
        }
        public int Height
        {
            get { return _texture.Height; }
        }
        public Vector2 Position
        {
            get { return _position; }
        }
       
        //abstract functions
        public abstract void Move(KeyboardState cks);
        public abstract void Shoot(GameTime gt, KeyboardState cks);
        
        //Virtual functions
        public virtual void Initialize(Texture2D texture, Texture2D bulletTexture, Vector2 position, TimeSpan rateOfBullets, int viewPortWidth, int viewPortHeight)
        {
            _texture = texture;
            _bulletTexture = bulletTexture;
            _position = position;
            _active = true;
            _firstShot = false;
            _rateOfBullets = rateOfBullets;
            _health = 100;
            _viewPortWidth = viewPortWidth;
            _viewPortHeight = viewPortHeight;
            _bullets = new List<Bullet>();
    }
        //empty function
        public virtual void Update(GameTime gt, KeyboardState cks)
        {
            Move(cks);
            Shoot(gt, cks);
        }

        public virtual void Draw(SpriteBatch sb)
        {
            sb.Draw(_texture, _position, null, Color.White, 0f, Vector2.Zero, 1f, SpriteEffects.None, 0f);
            foreach (var b in _bullets)
            {
                b.Move();
                b.Draw(sb);
            }
        }

    }
}
