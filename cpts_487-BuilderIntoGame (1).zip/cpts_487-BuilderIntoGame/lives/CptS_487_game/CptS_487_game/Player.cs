﻿using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;

namespace CptS_487_game
{
    class Player : Entity
    {
        //Data members
        GraphicsDeviceManager graphics;
        protected float _speed;
        protected int _lives; //number of lives
        public Texture2D lives; //stars representing lives left
 
        //Getters/setters
        public float Speed //constant speed
        {
            get { return _speed; }
            set { _speed = value; }
        }
        public int Lives 
        {
            get { return _lives; }
            set { _lives = value; }
        }
        //Constructors
        public Player()
        {
            _speed = 8.0f;
            _lives = 3;
            

        }

        public void respawn(Vector2 spawnPos)
        {
            _position = spawnPos;
        }
        //overriden functions
        public override void Move(KeyboardState cks)
        {
            if (cks.IsKeyDown(Keys.Left))
            {
                _position.X -= _speed;
            }

            if (cks.IsKeyDown(Keys.Right))
            {
                _position.X += _speed;
            }

            if (cks.IsKeyDown(Keys.Up))
            {
                _position.Y -= _speed;
            }

            if (cks.IsKeyDown(Keys.Down))
            {
                _position.Y += _speed;
            }


            //Bound check
            _position.X = MathHelper.Clamp(_position.X, 0, _viewPortWidth - Width);
            _position.Y = MathHelper.Clamp(_position.Y, 0, _viewPortHeight - Height);
        }
        //Not implemented
        public override void Shoot(GameTime gt, KeyboardState cks)
        {
            if (!cks.IsKeyDown(Keys.Space)) { return; }
            if (!_firstShot)
            {
                _previousBulletSpawnTime = gt.TotalGameTime;
                AddBullet();
                _firstShot = true;
            }
            if(gt.TotalGameTime - _previousBulletSpawnTime > _rateOfBullets)
            {
                _previousBulletSpawnTime = gt.TotalGameTime;
                AddBullet();
               
            }
        }


        public void AddBullet()
        {
            StraightBullet bullet = new StraightBullet();
            //DiagonalBullet bullet = new DiagonalBullet(); 
            //WaveBullet bullet = new WaveBullet();
            bullet.Initialize("bullet", _position, 20f, 3);
            _bullets.Add(bullet);
        }

        public void drawLives(SpriteBatch sb)
        {
         
            for(int i = 0; i < _lives; i++)
            {
                sb.Draw(lives, new Vector2(600 + (i*60), 400), null, Color.White, 0f, Vector2.Zero, 0.1f, SpriteEffects.None, 0f);
            }
            
        }

    }
}
