﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CptS_487_game;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace CptS_487_game
{
    class Bosses: Enemy
    {
        public Bosses(Texture2D newTexture, Vector2 newPosition, Texture2D newBulletTexture) : base(newTexture, newPosition, newBulletTexture)
        {

        }

        
    }
}
