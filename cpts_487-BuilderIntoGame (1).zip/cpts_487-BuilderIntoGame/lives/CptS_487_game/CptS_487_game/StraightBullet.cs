﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace CptS_487_game
{
    class StraightBullet : Bullet
    {
        
        public override void Initialize(string texture, Vector2 position, float speed, int damage)
        {
            _bulletTexture = Game1._content.Load<Texture2D>(texture);
            BulletMoveSpeed = speed;
            Position = position;
            Damage = damage;
            Active = true;
        }

        public override void Move()
        {
            //Just move straight
            Position.X += BulletMoveSpeed;
        }

    }
}