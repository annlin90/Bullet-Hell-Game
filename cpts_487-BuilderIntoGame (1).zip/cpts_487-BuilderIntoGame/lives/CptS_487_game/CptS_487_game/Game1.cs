﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;



namespace CptS_487_game
{
    /// <summary>
    /// This is the main type for your game.
    /// </summary>
    public class Game1 : Game
    {
        SpriteFont font;

        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        Player player;
        Enemy enemy;
        Menu menu;
        public static ContentManager _content { get; set; }
        //States to determine key presses
        KeyboardState currentKState;
        KeyboardState prevKState;

        List<Enemy> enemies = new List<Enemy>();
        List<Enemy> enemies2 = new List<Enemy>();

        Random random = new Random();

        Texture2D playerTexture;
        Texture2D bulletTexture;

        Texture2D enemy1;
        Texture2D enemy2;

        Texture2D life;
        enum GameState { menu, game, gameOver, win };
        //GameState curState = GameState.menu;
        State curState;


        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            _content = Content;
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            this.IsMouseVisible = true;
            //Create player obj
            player = new Player();

            menu = new Menu();
            curState = new State();
            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);
            //health
            font = Content.Load<SpriteFont>("File");
            //Load player resources
            playerTexture = Content.Load<Texture2D>("rf");
            bulletTexture = Content.Load<Texture2D>("bullet");
            player.lives = Content.Load<Texture2D>("star");
            Vector2 playerPosition = new Vector2(GraphicsDevice.Viewport.TitleSafeArea.X, GraphicsDevice.Viewport.TitleSafeArea.Y + GraphicsDevice.Viewport.TitleSafeArea.Height / 2);
            player.Initialize(playerTexture, bulletTexture, playerPosition, TimeSpan.FromSeconds(60f / 200f), GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height);

            menu.Initialize(font);
            curState.Initialize(font);
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// game-specific content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        /// 
        float spawn = 0;
        float spawn2 = 0;




        protected void UpdateCollision()
        {
           
            // Use the Rectangle's built-in intersect function to 
            // determine if two objects are overlapping
            Rectangle rectangle1;
            Rectangle rectangle2;
            Rectangle rectangle3;
            Rectangle rectangle4;

            // Create a rectrangle for player
            rectangle1 = new Rectangle((int)player.Position.X, (int)player.Position.Y, playerTexture.Width, playerTexture.Height);

           
            // Kill the player when colliding with DemonEnemy
            for (int i = 0; i < enemies.Count; i++)
            {
                ////rect3 is for projectiles
                //rectangle3 = new Rectangle((int)enemies[i]._bullets[i].Position.X, (int)enemies[i]._bullets[i].Position.Y,
                //     bulletTexture.Width, bulletTexture.Height);

                rectangle2 = new Rectangle((int)enemies[i].Position.X, (int)enemies[i].Position.Y, enemy1.Width, enemy1.Height);
                if (rectangle1.Intersects(rectangle2))
                {
                    Vector2 playerPosition = new Vector2(GraphicsDevice.Viewport.TitleSafeArea.X, GraphicsDevice.Viewport.TitleSafeArea.Y + GraphicsDevice.Viewport.TitleSafeArea.Height / 2);
                    player.Lives -= 1;
                    player.respawn(playerPosition);
                    if(player.Lives <= 0)
                    {
                        //end game
                        //curState = GameState.gameOver;
                        curState.gs = curState.setState("gameOver");
                    }
                    enemies.RemoveAt(i);
                    i--;

                }
            }

           
            // Check if fireball intersects with demon enemy
            for (int i = 0; i <  player._bullets.Count; i++)
            {
                for (int x = 0; x < enemies.Count; x++)
                {
                    rectangle4 = new Rectangle((int)player._bullets[i].Position.X, (int)player._bullets[i].Position.Y,
                     bulletTexture.Width, bulletTexture.Height);

                    rectangle2 = new Rectangle((int)enemies[x].Position.X, (int)enemies[i].Position.Y, enemy1.Width, enemy1.Height);

            if (rectangle4.Intersects(rectangle2))
                    {
                        // Subtract demon health when fireball hits
                        enemies.RemoveAt(i);
                        x--;
                        // Remove fireball from list
                       player._bullets.RemoveAt(i);
                        i--;

                       
                    }
                }
            }      

        }



        protected override void Update(GameTime gameTime)
        {
            var mouseState = Mouse.GetState();
            var mousePoint = new Point(mouseState.X, mouseState.Y);
            var hover = new Rectangle(200, 265, 200, 35);
            //player.Update(gameTime);
            if (menu.Update(gameTime) == 1)
            {
                curState.gs = curState.setState("game");
            }
            if (curState.Update(gameTime))
            {
                if (hover.Contains(mousePoint) && mouseState.RightButton == ButtonState.Pressed)
                {
                    Exit();
                }
            }
            
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape)
                ||menu.Update(gameTime) == 2)
                Exit();

            //Save previous states
            prevKState = currentKState;

            //Read current states
            currentKState = Keyboard.GetState();

            //Update player position
            player.Update(gameTime, currentKState);

            spawn += (float)gameTime.ElapsedGameTime.TotalSeconds;
            foreach(Enemy enemy in enemies)
            {
                enemy.Update(graphics.GraphicsDevice);
            }

            LoadEnemies();
            UpdateCollision();
            base.Update(gameTime);
        }

        public void LoadEnemies()
        {
           

            int randY = random.Next(100, 400);
            int randY2 = random.Next(110, 360);

            enemy1 = Content.Load<Texture2D>("astro");
            enemy2 = Content.Load<Texture2D>("ship2");

            if (spawn >=1)
            {
                spawn = 0;
                if(enemies.Count<4) 
                {
                   enemies.Add(new Enemy((Content.Load<Texture2D>("astro")), new Vector2(1100, randY), Content.Load<Texture2D>("bullet")));
                   enemies.Add(new Enemy((Content.Load<Texture2D>("ship2")), new Vector2(1150, randY2), Content.Load<Texture2D>("bullet")));

                }

                for (int i = 0; i <enemies.Count; i++)
                {
                    if (!enemies[i].isVisible)
                    {
                        enemies.RemoveAt(i);
                        i--;
                    }
                }
            }
        }

       

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        /// 



        protected override void Draw(GameTime gameTime)
        {
            var mouseState = Mouse.GetState();
            var mousePoint = new Point(mouseState.X, mouseState.Y);

            GraphicsDevice.Clear(Color.GhostWhite);
            //Start drawing
            spriteBatch.Begin();
            // spriteBatch.DrawString(font, "" + mousePoint, new Vector2(200, 410), Color.Black);

            if (curState.gs == State.GameState.gameOver)
            {
                spriteBatch.DrawString(font, "Game Over!", new Vector2(200, 210), Color.Black);
            }
            if (curState.gs == State.GameState.win)
            {
                spriteBatch.DrawString(font, "YOU WIN!", new Vector2(200, 210), Color.Black);
            }
            if (curState.gs == State.GameState.win || curState.gs == State.GameState.gameOver)
            {
                var fColor = new Color();
                fColor = Color.Black;
                var hover = new Rectangle(200, 265, 200, 35);

                if (hover.Contains(mousePoint))
                {
                    fColor = Color.Red;
                }

                spriteBatch.DrawString(font, "End Game", new Vector2(200, 265), fColor);
            }
            if (curState.gs == State.GameState.menu)
            {
                GraphicsDevice.Clear(Color.Crimson);
                menu.Draw(spriteBatch);
            }
            //draw health
            //spriteBatch.DrawString(font, "Lives: " + player.Lives, new Vector2(200, 410), Color.Black);
            if (curState.gs == State.GameState.game)
            {
                //Draw player
                player.Draw(spriteBatch);
                //draw player lives with # of stars
                player.drawLives(spriteBatch);
               // spriteBatch.DrawString(font, "Menu", new Vector2(450, 410), Color.Black);
                foreach (Enemy enemy in enemies)
                {
                    enemy.Draw(spriteBatch);
                }
            }

            //Stop drawing
            spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
