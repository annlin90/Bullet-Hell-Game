﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;



namespace CptS_487_game
{
    class WaveBullet : Bullet
    {
        float _maxY, _minY;
        bool _goingUp;

        public WaveBullet()
        {
            
        }

        public override void Initialize(string texture, Vector2 position, float speed, int damage)
        {
            _bulletTexture = Game1._content.Load<Texture2D>(texture);
            BulletMoveSpeed = speed;
            Position = position;
            Damage = damage;
            _maxY = position.Y + 50;
            _minY = position.Y - 50;
            _goingUp = true;
            Active = true;
        }

        public override void Move()
        {
            //If the position is going up and less than max
            if (Position.Y < _maxY && _goingUp)
            {
                //Move the lazer up
                Position.Y += 20;
            }
            //if the position is above the min and not going up
            else if (Position.Y > _minY && !_goingUp)
            {
                //move the bullet down
                Position.Y -= 20;
            }
            //if the position is above the max
            else if (Position.Y >= _maxY)
            {
                //stop going up
                _goingUp = false;
            }
            //if the position is under the min
            else if (Position.Y <= _minY)
            {
                //start going back up
                _goingUp = true;
            }
            //Move the bullet forward
            Position.X += BulletMoveSpeed;
        }
    }
}
