﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using CptS_487_game;
using System.Collections.Generic;

namespace CptS_487_game
{
    class Enemy : Entity
    {
        // animation represneting the enemy.
        public Animation EnemyAnimation;

        // The postion of the enemy ship relative to the 
        // top of left corner of the screen
        public Vector2 Position;

        // state of the enemy ship
        public bool Active;
        // Hit points of the enemy, if this goes
        // to zero the enemy dies.      
        public int Health;

        // the amount of damage that the enemy
        // ship inflicts on the player.
        public int Damage;

        // the amount of the score enemy is worth.
        public int Value;

        Random random = new Random();
        public Texture2D texture;
        public Vector2 velocity;

        public bool isVisible = true;

        int randX, randY;

        //Bullets
        List<Bullet> bullets = new List<Bullet>();
        Texture2D bulletTexture;

        // Get the width of the enemy ship
        public int Width
        {
            get
            {
                return EnemyAnimation.FrameWidth;
            }
        }

        // Get the height of the enemy ship.
        public int Height
        {
            get { return EnemyAnimation.FrameHeight; }
        }

        public float enemyMoveSpeed;

        public void Initialize(Animation animation,
            Vector2 position)
        {
            // load the enemy ship texture;
            EnemyAnimation = animation;

            // set the postion of th enemy ship
            Position = position;

            // set the enemy to be active
            Active = true;

            // set the health of the enemy
            Health = 10;

            // Set the amount of damage the enemy does
            Damage = 10;

            // Set how fast the enemy moves.
            enemyMoveSpeed = 10;

            // set the value of the enemy
            Value = 100;
        }

        public Enemy(Texture2D newTexture, Vector2 newPosition, Texture2D newBulletTexture)
        {
            texture = newTexture;
            Position = newPosition;


            randY = random.Next(-4, 4);
            randX = random.Next(-4, -1);

            velocity = new Vector2(randX, randY);
        }

        public void Update(GraphicsDevice graphics)
        {
            Position += velocity;

            if (Position.Y <= 0 || Position.Y >= graphics.Viewport.Height - texture.Height)
            {
                velocity.Y = -velocity.Y; 
            }

            if(Position.X < 0 - texture.Width)
            {
                isVisible = false;
            }
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            // draw the animation
            //EnemyAnimation.Draw(spriteBatch);
            spriteBatch.Draw(texture, Position, Color.White);
        }

        public override void Move(KeyboardState cks)
        {
            
            //Bound check
           // _position.X = MathHelper.Clamp(_position.X, 0, _viewPortWidth - Width);
            //_position.Y = MathHelper.Clamp(_position.Y, 0, _viewPortHeight - Height);
        }
        //Not implemented
        public override void Shoot(GameTime gt, KeyboardState cks)
        {
           /* if (!cks.IsKeyDown(Keys.Space)) { return; }
            if (!_firstShot)
            {
                _previousBulletSpawnTime = gt.TotalGameTime;
                AddBullet();
                _firstShot = true;
            }
            if (gt.TotalGameTime - _previousBulletSpawnTime > _rateOfBullets)
            {
                _previousBulletSpawnTime = gt.TotalGameTime;
                AddBullet();
            }*/
        }


    }
}

