﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace CptS_487_game
{
    abstract class Bullet
    {
        //abstract Bullet class. 
        //contains basic functions that
        //    retrieve information from animation
        //  -Width
        //  -Height
        //  -Update
        //  -Draw
        //functions to overwrite:
        //  -Initialize: make each concrete bullet set their own values
        //  -Move: function that moves the bullet, concrete bullets have their own movement
        //      (more to come in fututre updates)
        //Filestream 
        //graphics = new GraphicsDeviceManager();
        // Content.RootDirectory = "Content";


        //Animation for the bullet
        //public Animation _bulletAnimation;
        
        //Speed the bullet moves
        public float BulletMoveSpeed;

        // position of the bullet
        public Vector2 Position;

        public Vector2 Velocity;

        public bool isVisible;

        // The damage the bullet deals.
        public int Damage;

        // set the bullet to active
        public bool Active;

        // Laser beams range.
        public int Range;

        // texture to hold the bullet.
        protected Texture2D _bulletTexture;

        public abstract void Move();
        public abstract void Initialize(string imageName, Vector2 position, float speed, int damage);

        // the width of the bullet image.
        public int Width
        {
            get { return _bulletTexture.Width; }

        }
        // the height of the bullet image.
        public int Height
        {
            get { return _bulletTexture.Height; }
        }

        public void Update(GameTime gameTime)
        {
            Move();
            //BulletAnimation.Position = Position;
            //BulletAnimation.Update(gameTime);

        }

        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(_bulletTexture, Position, null, Color.White, 0f, Vector2.Zero, 1f,
                                    SpriteEffects.None, 0f);
        }

    }

}

